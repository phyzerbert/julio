var regex = /[0-9A-Fa-f]/;
