var a = /./;
var b = /./s;
